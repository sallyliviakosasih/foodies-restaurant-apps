import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.scss';
import '../styles/responsive.scss';
import './components/search-bar';
import App from './views/app';
import swRegister from './utils/sw-register';

const moreNaviDrawerButton = document.querySelector('#more-navi-list');
const naviDrawer = document.querySelector('#navi-list');
const mainPage = document.querySelector('#main');

const app = new App({
 moreNaviButton: moreNaviDrawerButton,
 naviList: naviDrawer,
 mainContent: mainPage,
});

window.addEventListener('hashchange', () => {
    app.renderPage();
  });

window.addEventListener('load', () => {
   app.renderPage();
   swRegister();
});

/*
const raw_data = data.restaurants;
const moreNaviListButton = document.querySelector('#more-navi-list');
const naviList = document.querySelector('#navi-list');
const mainPage = document.querySelector('main');
const searchInput = document.getElementById('search-input');
const resultColumn = document.querySelector('.results-column');
const searchButton = document.getElementById('search-button');
console.log('Hello Coders! :)');
moreNaviListButton.addEventListener('click', (event) => {
    naviList.classList.toggle('open');
    event.stopPropagation();
});
mainPage.addEventListener('click', (event) => {
    naviList.classList.remove('open');
    event.stopPropagation();
});

function loadData (){
    const catalogue = document.querySelector ('.restaurants');
    raw_data.forEach(data => {
        const data_container = document.createElement('div');
        data_container.classList.add('data-restaurant');

        const data_image = document.createElement('img');
        data_image.classList.add('pict-restaurant');
        data_image.setAttribute('alt','picture of restaurant');
        data_image.setAttribute('src',data.pictureId);

        const data_details = document.createElement('div');
        data_details.classList.add('restaurant-detail');

        const data_name = document.createElement('h3');
        data_name.classList.add('restaurant-name');
        data_name.innerText=data.name;

        const data_city = document.createElement('h4');
        data_city.classList.add('restaurant-city');
        data_city.innerHTML=data.city;

        const data_rates = document.createElement('h4');
        data_rates.classList.add('restaurant-rates');
        data_rates.innerText=data.rating;

        const data_desc = document.createElement('p');
        data_desc.classList.add('restaurant-desc');
        data_desc.innerText=data.description;

        data_details.append(data_name, data_city, data_rates,data_desc);
        data_container.append(data_image,data_details);
        catalogue.appendChild(data_container);
    });
}
loadData();

searchButton.addEventListener('click',()=>{
    resultColumn.innerHTML=" ";
    console.log(resultColumn);
    const user_input = searchInput.value.toLowerCase();
    for(const eachData of raw_data){
        if(eachData.name.toLowerCase().indexOf(user_input)>-1){
            const resultBox = document.createElement('div');
            resultBox.classList.add('result');

            const resultPict = document.createElement('img');
            resultPict.classList.add('pict-result');
            resultPict.setAttribute('src',eachData.pictureId);
            resultPict.setAttribute('alt', 'picture of restaurant result')

            const resultName = document.createElement('h4');
            resultName.classList.add('restaurant-result-name');
            resultName.innerText=eachData.name;

            const resultCity = document.createElement('h5');
            resultCity.classList.add('restaurant-result-city');
            resultCity.innerText=eachData.city;

            const resultRates = document.createElement('h5');
            resultRates.classList.add('restaurant-result-rates');
            resultRates.innerText=eachData.rating;

            const resultDesc = document.createElement('p');
            resultDesc.classList.add('restaurant-result-desc');
            resultDesc.innerText=eachData.description;

            resultBox.append(resultPict, resultName, resultCity, resultRates, resultDesc);
            resultColumn.appendChild(resultBox);
        }
    }
})

searchInput.addEventListener('keydown',()=>{
    resultColumn.innerHTML=" ";
})
*/

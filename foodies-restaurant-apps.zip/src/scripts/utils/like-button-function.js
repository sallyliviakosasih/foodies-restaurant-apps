import FavoriteRestaurantsIdb from '../data/favorite-restaurants-idb';
import { createLikeButtonTemplate, createUnlikeButtonTemplate } from '../views/templates/template-creator';

const LikeButtonFunction = {
    async init({ likeButtonContainer, DataRestaurant }) {
        this._likeButtonContainer = likeButtonContainer;
        this._DataRestaurant = DataRestaurant;

        await this._renderButton();
    },

    async _renderButton() {
        const { id } = this._DataRestaurant;
        if (await this._isDataRestaurantStored(id)) {
            this._renderUnlike();
        } else {
            this._renderLike();
        }
    },

    async _isDataRestaurantStored(id) {
        const DataRestaurant = await FavoriteRestaurantsIdb.getRestaurant(id);
        return !!DataRestaurant;
    },

    _renderLike() {
        this._likeButtonContainer.innerHTML = createLikeButtonTemplate();
        const likeButton = document.querySelector('#likeButton');
        likeButton.addEventListener('click', async () => {
            await FavoriteRestaurantsIdb.updateDataRestaurant(this._DataRestaurant);
            this._renderButton();
        });
    },

    _renderUnlike() {
        this._likeButtonContainer.innerHTML = createUnlikeButtonTemplate();
        const likeButton = document.querySelector('#unlikeButton');
        likeButton.addEventListener('click', async () => {
            await FavoriteRestaurantsIdb.deleteRestaurant(this._DataRestaurant.id);
            this._renderButton();
        });
    },

};

export default LikeButtonFunction;
